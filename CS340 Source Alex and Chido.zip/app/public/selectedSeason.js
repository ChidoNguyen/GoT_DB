function selectSeason(id) {
    $("#season-selector").val(id);
}