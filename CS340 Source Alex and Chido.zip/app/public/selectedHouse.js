function selectHouse(id) {
    $("#house-selector").val(id);
}