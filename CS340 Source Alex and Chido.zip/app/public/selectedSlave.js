function selectSlave(id) {
    $("#slave-selector").val(id);
}