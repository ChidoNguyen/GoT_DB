function selectLocation(id) {
    $("#location-selector").val(id);
}